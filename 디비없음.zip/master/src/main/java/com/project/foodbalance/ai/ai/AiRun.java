package com.project.foodbalance.ai.ai;

public class AiRun {

	public static void main(String[] args) {
		
		PythonAi ai = new PythonAi();
		// TODO Auto-generated method stub

	}

}
